package Demo3;

import java.util.Scanner;

public class TestJdbc2 
{
 public static void main(String[] args)
 {
	 Scanner sc=new Scanner(System.in);
	 Register r=new Register();
	/* System.out.println("enter username");
	 String name=sc.next();
	 System.out.println("enter password");
	 String p=sc.next();*/
	// r.signIn(name,p);
	 r.signUp();
  }
 }
