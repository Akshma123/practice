package Demo2;

import java.sql.Connection;

public class TestJdbc
{
  public static void main(String args[])
  {
	  MakeConnection makeconnection=new MakeConnection();
	  Connection conn=makeconnection.makeConnection();
	  Operations o=new Operations();
	  //o.insert();
	//  o.read();
	// o.delete();
	 //o.read();
	 // o.create();
	  o.insert();
	  o.read();
	 
	
  }
}
