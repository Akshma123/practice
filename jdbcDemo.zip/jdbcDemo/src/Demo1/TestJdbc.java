package Demo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestJdbc 
{
 public static void main(String args[])
 {
	 Connection conn=null;
	 try
	 {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
		PreparedStatement pstmt=conn.prepareStatement("select * from Book122 where bookId=?");
		pstmt.setInt(1,101);
		ResultSet resultset=pstmt.executeQuery();
		while(resultset.next())
		{
			int bookId=resultset.getInt(1);
			String bookName=resultset.getString(2);
			float price=resultset.getFloat(3);
			System.out.println(bookId+" "+bookName+" "+price);
		}
		
	} 
	 catch (ClassNotFoundException e)
	{
		e.printStackTrace();
	} 
	 catch (SQLException e) {
		e.printStackTrace();
	}
	 finally
	 {
		 try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 }
 }
}
