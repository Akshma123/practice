package com.nucleus.errorlog;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ErrorLog 
{
	public void saveToFile(String line)
	{
		FileWriter filewriter;
		try {
			filewriter = new FileWriter("errorlog.txt",true);
			PrintWriter printwriter=new PrintWriter(filewriter);
			printwriter.write(line);
			printwriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
			
	}
}
