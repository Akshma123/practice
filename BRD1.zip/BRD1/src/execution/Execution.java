package execution;

import java.nio.file.Files;
import java.util.Scanner;

import com.nucleus.dao.CustomerDao;
import com.nucleus.dao.CustomerDaoImplementation;
import com.nucleus.domain.Customer;
public class Execution
{
 public static void main(String[] args)
 {
	 Scanner sc=new Scanner(System.in);
	Customer customer=new Customer();
	CustomerDao customerDao=new CustomerDaoImplementation();
	System.out.println("enter file location");
	String location=sc.next();
	
	int x=1;
	String loc=null;
	while(x==1)
	{
		System.out.println("enter file name");
		String filename=sc.next();
		if(filename.endsWith(".txt"))
				{
	    loc=location.concat("\\"+filename);	
	 x=2;
				}
		else
		{
			System.out.println("enter file with .txt extension");
			
		}
	}
  
	customerDao.readFromFile(loc);
 }
}
