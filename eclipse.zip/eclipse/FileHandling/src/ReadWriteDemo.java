import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class ReadWriteDemo 
{
	public void saveToFile(String name)
	{
		FileWriter filewriter;
		try {
			filewriter = new FileWriter("abc.txt");
			PrintWriter printwriter=new PrintWriter(filewriter);
			printwriter.write(name);
			printwriter.flush();
			System.out.println("created");
		} catch (IOException e) {
			e.printStackTrace();
		}
			
	}
	public void readFromFile()
	{
		FileReader filereader;
		try {
			filereader = new FileReader("abc.txt");
			BufferedReader bufferreader=new BufferedReader(filereader);
			String text=bufferreader.readLine();
			System.out.println(text);
			while(text!=null)
			{
				System.out.println(text);
				text=bufferreader.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
  public static void main(String[] args)
  {
	ReadWriteDemo r=new ReadWriteDemo();
	r.saveToFile("akki");
  }
}
 