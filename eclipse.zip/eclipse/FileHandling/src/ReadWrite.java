import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

//serialization
public class ReadWrite 
{
  public void saveBook(Book book)
  {
	  FileOutputStream fileOutputStream;
	try {
		fileOutputStream = new FileOutputStream("file01");
		ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
		  objectOutputStream.writeObject(book);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
  }
  //Deserialazartion
  public void displayBook()
  {
	  FileInputStream fileInputStream;
	try {
		fileInputStream = new FileInputStream("file01");
		ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
		  Book book1=(Book)objectInputStream.readObject();
		  System.out.println(book1.bookId+" "+book1.name);
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
		
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	}
	  
  }
}
class TestReadWrite 
{
	public static void main(String[] args)
	{
		ReadWrite r=new ReadWrite();
		Book book=new Book();
		r.saveBook(book);
		r.displayBook();
	}
}