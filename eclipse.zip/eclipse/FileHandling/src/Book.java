import java.io.Serializable;


public class Book implements Serializable
{
    int bookId=9;
    String name="akki";
}
