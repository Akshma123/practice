package ques1;
import java.util.*;
public class BowlersDetails 
{
  void bestBowlers(String[] details,int num)
  {
	  int count=0;
	for(int i=0;i<num;i++)
	{
		double sum=0;
		
		String[] arr=details[i].split("");
		int length=arr.length;
		for(int j=0;j<length;j++)
		{
		int a=Integer.parseInt(arr[j]);
		//System.out.println(a);
		sum+=a;
		}
		//System.out.println(sum);
		double avg=sum/length;
		if(avg>=5.0)
		{
			//System.out.println("loop");
			count++;
		}
	}
	System.out.println(count);
  }
}
class FindBestBowler
{
	public static void main(String[] args)
	{
		BowlersDetails b=new BowlersDetails ();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of bowlers");
		int noOfBowlers=sc.nextInt();
		if(noOfBowlers==0)
			System.out.println("no bowlers for given year");
		String details[]=new String[noOfBowlers];
		System.out.println("enter the details of Bowlers ");
		for(int i=0;i<noOfBowlers;i++)
		{
			details[i]=sc.next();
		}
		System.out.print("{");
		for(int i=0;i<noOfBowlers;i++)
		{
			System.out.print(details[i]);
			if((i+1)!=noOfBowlers)
			System.out.print(",");
		}
		System.out.println("}");
		b.bestBowlers(details,noOfBowlers);
	}
}