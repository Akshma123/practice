package ques2;
import java.util.*;
public class Original
{
 void check(int[] arr,int num)
 {
	// int[] copy=arr;
	 int[] arr1=new int[num];
	for(int i=0;i<num;i++)
	{
		int j=0;
		int x;
		x=arr[i];
		if((i+2)>=num)
		{
			arr1[j]=x;
		j++;
		}
		else if(arr[i+1]==(x+1)&&arr[i+2]==(x+2))
		{
			arr1[j]=arr[i+1];
			j++;
		}
		else
		{
			arr1[j]=x;
			j++;
		}
		
	}
	for(int k=0;k<arr1.length;k++)
		System.out.print(arr[k]+" ");
 }
}
 class TestOriginal
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no. of matches");
		int num=sc.nextInt();
		int[] arr=new int[num];
		System.out.println("enter score");
		for(int i=0;i<num;i++)
			arr[i]=sc.nextInt();
		Original o=new Original();
		o.check(arr,num);
	}
}