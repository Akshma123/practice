package list;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Student
{
 int id;
 String name;

 Student(int id,String name)
 {
	this.id=id;
	this.name=name;
 }
 Student()
 {
	 
 }
 public String toString()
 {
	 return("id is:"+id+" and name is:"+name);
 }
 /*public static void getAllStudents(List<Student> l)
 {
	for(Student l1:l)
	{
		//if(l1.id%2==0)
		System.out.println(l1);
	}
 }*/ 
 public  List<Student> getAllStudents(List<Student> l)
 {
	return l;
 }
 public void getAllSortedStudent()
 {
	 
 }
 public void getStudent()
 {
	 
 }
 public void updateStudent()
 {
	 
 }
 public void deleteStudent()
 {
	 
 }
 public void save()
 {
	 
 }
}
class TestArrayList
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		 List<Student> l=new ArrayList<Student>();
	 Student s= s=new Student();;
	 int var=1;
	 while(var==1)
	 {
		 System.out.println("enter id");
		 int id=sc.nextInt();
		 System.out.println("enter name");
		 String name=sc.next();
		 l.add(new Student(id,name));
		 System.out.println("enter 1 to add more student and 0 for exit");
		 int choice=sc.nextInt();
		 if(choice==0)
			 var=0;
	 }
	 int var1=1;
	 while(var1==1)
	 {
	 System.out.println("enter 1 to get all data");
	 System.out.println("enter 2 to get all sorted data");
	 System.out.println("enter 3 to get student");
	 System.out.println("enter 4 to update the student record");
	 System.out.println("enter 5 to delete the student record");
	 System.out.println("enter 6 to save the data");
	 System.out.println("enter 7 to exit");
	 int choice=sc.nextInt();
	 
	 switch(choice)
	 {
	 case 1:
		 List<Student> list=s.getAllStudents(l);
		 System.out.println(list);
		 break;
	 case 2:
		 s.getAllSortedStudent();
		 break;
	 case 3:
		 s.getStudent();
		 break;
	 case 4:
		 s.updateStudent();
		 break;
	 case 5:
		 s.deleteStudent();
		 
		 break;
	 case 6:
		 s.save();
		 break;
	 case 7:
		 var1=0;
	 }
	 }
	
	
	}
}
