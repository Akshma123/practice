package list;

import java.util.ArrayList;
import java.util.List;

public class List1 
{
 int id=3;
 List<List1> l;
 List1(List<List1> list)
 {
	 l=list;	
 }
 List1()
 {
	 
 }
 public String toString()
 {
	 return("id is:"+id);
 }
 public List<List1> get()
 {
	 return l;
 }
}
class TestList1 extends List1
{
	TestList1(List<List1> list)
	{
		super(list);
	}
	TestList1()
	{
		
	}
	public static void main(String[] args)
	{
		
		List<List1> list=new ArrayList<List1>();
     List1 l=new List1();
		l.id=5;
		list.add(l);
		
		//TestList1 l1=new TestList1(list);
		TestList1 l1=new TestList1();
		l1.l=list;
		List<List1> final1=l1.get();
		System.out.println(final1);
	}
}