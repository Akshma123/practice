package list;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentArrayList
{
	Scanner sc=new Scanner(System.in);
    int id;
    String name;
    List<StudentArrayList> list1;
    void enterInfo()
    {
		System.out.println("enter id");
		int id=sc.nextInt();
		this.id=id;
    	System.out.println("enter name");
    	String name=sc.next();
    	this.name=name;
    	
    }
    public String toString()
    {
    	return(id+":"+name);
    }
    List<StudentArrayList> get()
    {
    	return list1;
    }
}
class TestStudentArrayList 
{
	 
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		List<StudentArrayList> list=new ArrayList<StudentArrayList>();
		StudentArrayList s=new StudentArrayList();
		System.out.println("enter details");
		int choice=1;
		while(choice==1)
		{
		s.enterInfo();
		list.add(s);
		System.out.println("wanna enter more details..press 1 for yes");
		choice=sc.nextInt();
		}
		s.list1=list;
		int var1=1;
		while(var1==1)
		{
		System.out.println("enter 1 for get");
		System.out.println("enter 2 for exit");
		int c=sc.nextInt();
		switch(c)
		{
		case 1:
		List<StudentArrayList> list2=s.get();
		System.out.println(list2);
		break;
		case 2:
			var1=0;
		}
	}
}
}
