import java.util.*;
import java.lang.Math.*;
class FindPower
{
 void power(int value1,int value2)
 {
  System.out.println(Math.pow(value1,value2));
 }
 void power(int value1,double value2)
 {
  System.out.println(Math.pow(value1,value2));
 }
 void power(double value1,int value2)
 { 
  System.out.println(Math.pow(value1,value2));
 }
 void power(double value1,double value2)
 {
  System.out.println(Math.pow(value1,value2));
 }
}
class TestFindPower
{
 public static void main(String[] args)
 {
  FindPower p=new FindPower();
  Scanner sc=new Scanner(System.in);
  
 p.power(2.2,3.4);
 }
}
