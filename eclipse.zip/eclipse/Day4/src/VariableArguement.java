//var arg method
public class VariableArguement 
{
   public static void main(String[] args)
   {
	   Sumarr s=new Sumarr();
	   int am[]={1,2};
	  int a= s.sum(am);
	  System.out.println(a);
   }
}
class Sumarr
{
	int sum(int... values)
	{
		 int s=0;
		for(int i:values)
		{
			s=s+i;
		}
		return s;	
	}
}
