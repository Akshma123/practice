
public class DiffConsIns {
	{
		System.out.println("instance block");
	}
	DiffConsIns()
	{
		System.out.println("constructor");
	}
	void display()
	{
		System.out.println("hello");
	}

}
class TestDiff
{
	public static void main(String[] args)
	{
		DiffConsIns d=new DiffConsIns();
		d.display();
		d.display();
		DiffConsIns d1=new DiffConsIns();
	}
}