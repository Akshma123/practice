
public class ParCons
{
   public static void main(String[] args)
   {
	   PSubClass psb=new PSubClass();
	   //PSuperClass psb1=new PSuperClass();
	  psb.add(5, 6);
   }
}
class PSuperClass
{
	/*PSuperClass(String color,int num)
	{
		System.out.println("superclass constructor"+color+" "+num);
	}*/
	public static void add(int a,int b)
	{
		int c;
		c=a+b;
		System.out.println(c);
	}
}
class PSubClass extends PSuperClass
{
    /* PSubClass()
     {
    	 super("blue",5);
    	System.out.println("subclass constructor"); 
     }*/
	public static  void add(int a,int b)
	{    
		//it will not work(method hiding example)
		//super.add(3,4);        
		int c;
		c=a+b;
		System.out.println("a+"+"b="+c);
	}
}
