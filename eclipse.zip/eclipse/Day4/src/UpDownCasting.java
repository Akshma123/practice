import java.util.Scanner;


public class UpDownCasting
{
	public void displayDetails(Account a)    //upcasting
	{
		if(a instanceof SavingAccount)
		{
		SavingAccount sa=(SavingAccount)a;	       //downcasting
		sa.interest();
		}
		if(a instanceof CurrentAccount)
		{
			CurrentAccount ca=(CurrentAccount)a;
			ca.interest();
		}
	}
	public static void main(String[] args)
	{
       Account a=new Account();	
       
       UpDownCasting d=new UpDownCasting();
       Scanner sc=new Scanner(System.in);
       System.out.println("enter 1 for saving and 2 for account");
       int s=sc.nextInt();
       switch(s)
       {
       case 1:
       {
    	    a=new SavingAccount();
    	    d.displayDetails(a);
    	    break;
       }
        case 2:
        {
	    a=new CurrentAccount();
	    d.displayDetails(a);
	    break;
        }
         default:
		System.out.println("wrong");
       }
	}
       
}
class Account
{
	
}
class SavingAccount extends Account
{
	public void interest()
	{
		System.out.println("saving account interest");
	}
}
class CurrentAccount extends Account
{
	public void interest()
	{
	 System.out.println("current account interest");	
	}
}
/*class Details
{
public void displayDetails(Account a)
{
	if(a instanceof SavingAccount)
	{
	SavingAccount sa=(SavingAccount)a;	       //downcasting
	sa.interest();
	}
	if(a instanceof CurrentAccount)
	{
		CurrentAccount ca=(CurrentAccount)a;
		ca.interest();
	}
}
}*/