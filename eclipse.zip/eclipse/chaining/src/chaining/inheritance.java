package chaining;

public class inheritance {
public inheritance()
{
	System.out.println("superclass");
}
public static void main(String[] args)
{
	new inheritance1();
	
}
}
class inheritance1 extends inheritance
{
	public inheritance1()
	{
		System.out.println("subclasss");
	}
}
