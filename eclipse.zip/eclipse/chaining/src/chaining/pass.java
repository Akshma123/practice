package chaining;

public class pass {
int a=6;
int b=5;
public int add()
{
	int c=a+b;
	return c;
}
}
class Pass2
{
	public void m1(pass p)
	{
		System.out.println(p.add());
	}
}
class TestPass
{
	public static void main(String[] args)
	{
		pass p=new pass();
	     Pass2 p2=new Pass2();
	     p2.m1(p);
	}
}
