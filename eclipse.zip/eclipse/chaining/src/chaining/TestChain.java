//constructor chaining within same class
package chaining;

public class TestChain {
TestChain()
{
	System.out.println("default constructor");
}
TestChain(int n)
{
	this(3,4);
	System.out.println(n);
}
TestChain(int a,int b)
{
	 this();
	System.out.println(a+" "+b);
}
}
class Test
{
	public static void main(String[] args)
	{
		TestChain t=new TestChain(5);
	}
}
