package chaining;

public class TestChain2 {
TestChain2()
{
	
}
}
class Class2 extends TestChain2
{
	
	Class2()
	{
		super();
	
	}
}
class Test2
{
	public static void main(String[] args)
	{
		Class2 c=new Class2();
	}
}
