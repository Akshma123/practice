package com.nucleus.errorlog;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ErrorLog 
{
	public void saveToFile(String line)
	{
		FileWriter filewriter;
		try {
			filewriter = new FileWriter("errorlog.txt",true);
			PrintWriter printwriter=new PrintWriter(filewriter);
			printwriter.write(line + "\n");
			printwriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
			
	}
	
	public void copyFromFile(String send,StringBuffer str,String line)
	{
		FileReader fileReader = null;
		BufferedReader bufferReader = null;
		try {
			fileReader = new FileReader(send);
			bufferReader = new BufferedReader(fileReader);
			try {
				
					saveToFile(line+"error is: "+str);
					
				String l = bufferReader.readLine();
				while(l != null)
				{
					
					saveToFile(l);
					l = bufferReader.readLine();
					
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		finally
		{
			try {
				fileReader.close();
				bufferReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
