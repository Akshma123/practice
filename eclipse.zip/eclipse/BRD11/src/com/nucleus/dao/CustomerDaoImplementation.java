package com.nucleus.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Customer;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.validation.Validate;
public class CustomerDaoImplementation implements CustomerDao
{
	Customer customer=new Customer();
	Validate validate=new Validate();
	ErrorLog errorLog=new ErrorLog();
	ConnectionSetup connectionSetup=new ConnectionSetup();
	 Connection conn=connectionSetup.getConnection();
	

	 PreparedStatement pstmt;	
		ResultSet resultset;
		//to store the error message and pass with line in errorlog
		StringBuffer str=new StringBuffer("");
		String str1;
	//method to read from file	
   public void readFromFile(String loc, String choice) 
   {
	  int f=0;
	  
	FileReader fileReader;
	BufferedReader bufferedReader=null;
	try {
		fileReader = new FileReader(loc);
		 bufferedReader=new BufferedReader(fileReader);
		String line=bufferedReader.readLine();
		while(line!=null)
		{
			//auto commit set to false
			 conn.setAutoCommit(false);
		str1=line;
		//reading line by line from file and splitting it using separator
		String[] attribute=line.split("~",-1);
		int l=attribute[0].length();
		//validation for null and length
		if(validate.isNull(attribute[0],l,10))
		{
			f++;
			 str.append("CustomerCode:");
		}
		customer.setCustomerCode(attribute[0]);
		l=attribute[1].length();
		//validation for customer name
		if(validate.isCustomerNameValidate(attribute[1],l,30))
		{
			customer.setCustomerName(attribute[1]);
		}
		else
		{
			str.append("Customer Name:");
			f++;
		}
		l=attribute[2].length();
		//validation for address1
		if(validate.isNull(attribute[2],l,100))
		{
		f++;
		str.append("Address 1:");
		}
		customer.setCustomerAddress1(attribute[2]);
		l=attribute[3].length();
		//validation for address 2
		if(validate.isLengthValid(l,100))
		{
		customer.setCustomerAddress2(attribute[3]);
		}
		else
		{
			f++;
			str.append("Address 2:");
		}
		//validation for customer pin code length
		if(validate.isCustomerPinCodeValid(Long.parseLong(attribute[4])))
		{
		customer.setCustomerPinCode(Long.parseLong(attribute[4]));
		}
		else
		{
			str.append("pin code:");
			f++;
		}
		l=attribute[5].length();
		//validation for email address
		if(validate.isEmailValid(attribute[5],l,100))
		{
		customer.setEmailAddress(attribute[5]);
		}
		else
		{
			str.append("email address:");
			f++;
		}
		l=attribute[6].length();
		//validation for contact number
		if(validate.isLengthValid(l,20))
		{
		customer.setContactNo(Long.parseLong(attribute[6]));
		}
		else
		{
			str.append("contact no:");
			f++;	
		}
		l=attribute[7].length();
		//validation for primary contact person
		if(validate.isNull(attribute[7],l,100))
		{
			str.append("primary contact person:");
			f++;
		}
		customer.setPrimaryContactPerson(attribute[7]);
		l=attribute[8].length();
		//validation for record status
		if(validate.isRecordStatusValid(attribute[8],l,1))
		{
		customer.setRecordStatus(attribute[8]);
		}
		else
		{
			str.append("record status:");
			f++;
		}
		l=attribute[9].length();
		//validation for active inactive flag
		if(validate.isActiveInactiveFlagValid(attribute[9],l,1))
		{
		customer.setActiveInactiveFlag(attribute[9]);
		}
		else
		{
			str.append("Active Inactive flag:");
			f++;
		}
		if(validate.isNull(attribute[10],0,0))
		{
			str.append("create date:");
			f++;
		}
		customer.setCreateDate(attribute[10]);
		l=attribute[11].length();
		if(validate.isNull(attribute[11],l,30))
		{
			str.append("created by:");
			f++;
		}
		customer.setCreatedBy(attribute[11]);
		customer.setModifiedDate(attribute[12]);
		l=attribute[13].length();
		if(validate.isLengthValid(l,30))
		{
		customer.setModifiedBy(attribute[13]);
		}
		else
		{
			str.append("authorized date:");
			f++;
		}
		customer.setAuthorizedDate(attribute[14]);
		l=attribute[15].length();
		if(validate.isLengthValid(l,30))
		{
		customer.setAuthorizedBy(attribute[15]);
		}
		else
		{
			str.append("authorized by:");
			f++;
		}
		if(choice.equals("R"))
		{
		    if(f==0)
		    {
		insertDataInDatabase(customer);
		conn.commit();
		line=bufferedReader.readLine();
		    }
		    else
			{
				errorLog.saveToFile(line+"error......"+str);
				str=new StringBuffer("");
				line=bufferedReader.readLine();
				f=0;
			}
		}
		 else
		 {
			 if(f==0)
		     {
			insertDataInDatabase(customer);
			line=bufferedReader.readLine();
		     }
			 else
			{
				errorLog.copyFromFile(loc,str,line);
				      if(conn!=null)
				      conn.rollback();
					 System.exit(0);
			}
				
		}
		
	}
		if(choice.equals("F"))
			conn.commit();
		}
		catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		
		e.printStackTrace();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try {
			bufferedReader.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		connectionSetup.closeConnection();
	}
		
		}
		
		 
   public void insertDataInDatabase(Customer c)
   {
	   try 
	   {
		pstmt=conn.prepareStatement("insert into Customer_122 values(seq_122.nextVal,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		pstmt.setString(1,customer.getCustomerCode());
		pstmt.setString(2,customer.getCustomerName());
		pstmt.setString(3,customer.getCustomerAddress1());
		pstmt.setString(4,customer.getCustomerAddress2());
		pstmt.setLong(5,customer.getCustomerPinCode());
		pstmt.setString(6,customer.getEmailAddress());
		pstmt.setLong(7,customer.getContactNo());
		pstmt.setString(8,customer.getPrimaryContactPerson());
		pstmt.setString(9,customer.getRecordStatus());
		pstmt.setString(10,customer.getActiveInactiveFlag());
		pstmt.setString(11,customer.getCreateDate());
		pstmt.setString(12,customer.getCreatedBy());
		pstmt.setString(13,customer.getModifiedDate());
		pstmt.setString(14,customer.getModifiedBy());
		pstmt.setString(15,customer.getAuthorizedDate());
		pstmt.setString(16,customer.getAuthorizedBy());
		pstmt.executeUpdate();
	   } 
	   catch (SQLException e)
	   {
		errorLog.saveToFile(str1+"customer code should be unique");
		
		//e.printStackTrace();
	}
   }
}
