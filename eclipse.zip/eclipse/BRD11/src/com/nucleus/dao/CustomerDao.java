package com.nucleus.dao;

public interface CustomerDao 
{
  public void readFromFile(String loc, String choice);
}
