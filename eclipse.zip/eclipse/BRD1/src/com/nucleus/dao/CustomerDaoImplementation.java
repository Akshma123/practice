package com.nucleus.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Customer;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.validation.Validate;
public class CustomerDaoImplementation implements CustomerDao
{
	Customer customer=new Customer();
	Validate validate=new Validate();
	ErrorLog errorLog=new ErrorLog();
	ConnectionSetup connectionSetup=new ConnectionSetup();
	 Connection conn=connectionSetup.getConnection();
	 PreparedStatement pstmt;	
		ResultSet resultset;
		String str;
   public void readFromFile(String loc, String choice) 
   {
	  int f=0,k=0;
	  
	FileReader fileReader;
	try 
	{
		fileReader = new FileReader(loc);
		BufferedReader bufferedReader=new BufferedReader(fileReader);
		String line=bufferedReader.readLine();
		
		while(line!=null)
		{
			str=line;
		String[] attribute=line.split("~",-1);
		int l=attribute[0].length();
		if(validate.isNull(attribute[0],l,10))
		{
			f++;
		}
		customer.setCustomerCode(attribute[0]);
		l=attribute[1].length();
		System.out.println("length"+l);
		if(validate.isCustomerNameValidate(attribute[1],l,30))
		{
			customer.setCustomerName(attribute[1]);
		}
		else
		{
			f++;
		}
		l=attribute[2].length();
		if(validate.isNull(attribute[2],l,100))
		{
		f++;
		}
		customer.setCustomerAddress1(attribute[2]);
		l=attribute[3].length();
		if(validate.isLengthValid(l,100))
		{
		customer.setCustomerAddress2(attribute[3]);
		}
		else
		{
			f++;
		}
		if(validate.isCustomerPinCodeValid(Long.parseLong(attribute[4])))
		{
		customer.setCustomerPinCode(Long.parseLong(attribute[4]));
		}
		else
		{
			f++;
		}
		l=attribute[5].length();
		if(validate.isEmailValid(attribute[5],l,100))
		{
		customer.setEmailAddress(attribute[5]);
		}
		else
		{
			f++;
		}
		l=attribute[6].length();
		if(validate.isLengthValid(l,20))
		{
		customer.setContactNo(Long.parseLong(attribute[6]));
		}
		else
		{
			f++;	
		}
		l=attribute[7].length();
		if(validate.isNull(attribute[7],l,100))
		{
			f++;
		}
		customer.setPrimaryContactPerson(attribute[7]);
		l=attribute[8].length();
		if(validate.isRecordStatusValid(attribute[8],l,1))
		{
		customer.setRecordStatus(attribute[8]);
		}
		else
		{
			f++;
		}
		l=attribute[9].length();
		if(validate.isActiveInactiveFlagValid(attribute[9],l,1))
		{
		customer.setActiveInactiveFlag(attribute[9]);
		}
		else
		{
			f++;
		}
		if(validate.isNull(attribute[10],0,0))
		{
			f++;
		}
		customer.setCreateDate(attribute[10]);
		l=attribute[11].length();
		if(validate.isNull(attribute[11],l,30))
		{
			f++;
		}
		customer.setCreatedBy(attribute[11]);
		customer.setModifiedDate(attribute[12]);
		l=attribute[13].length();
		if(validate.isLengthValid(l,30))
		{
		customer.setModifiedBy(attribute[13]);
		}
		else
		{
			f++;
		}
		customer.setAuthorizedDate(attribute[14]);
		l=attribute[15].length();
		if(validate.isLengthValid(l,30))
		{
		customer.setAuthorizedBy(attribute[15]);
		}
		else
		{
			f++;
		}
		if(f==0)
		{
		insertDataInDatabase(customer);
		line=bufferedReader.readLine();
		}
		else
		{
			if(choice.equals("R"))
			{
				errorLog.saveToFile(line);
				line=bufferedReader.readLine();
				f=0;
			}
			
			else
			{
				errorLog.copyFromFile(loc);
				try {
					pstmt=conn.prepareStatement("delete from customer_122");
					pstmt.executeUpdate();
					System.exit(0);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		}
		}
		
		
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	    
	
   }  
   public void insertDataInDatabase(Customer c)
   {
	   try 
	   {
		pstmt=conn.prepareStatement("insert into Customer_122 values(seq_122.nextVal,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		pstmt.setString(1,customer.getCustomerCode());
		pstmt.setString(2,customer.getCustomerName());
		pstmt.setString(3,customer.getCustomerAddress1());
		pstmt.setString(4,customer.getCustomerAddress2());
		pstmt.setLong(5,customer.getCustomerPinCode());
		pstmt.setString(6,customer.getEmailAddress());
		pstmt.setLong(7,customer.getContactNo());
		pstmt.setString(8,customer.getPrimaryContactPerson());
		pstmt.setString(9,customer.getRecordStatus());
		pstmt.setString(10,customer.getActiveInactiveFlag());
		pstmt.setString(11,customer.getCreateDate());
		pstmt.setString(12,customer.getCreatedBy());
		pstmt.setString(13,customer.getModifiedDate());
		pstmt.setString(14,customer.getModifiedBy());
		pstmt.setString(15,customer.getAuthorizedDate());
		pstmt.setString(16,customer.getAuthorizedBy());
		pstmt.executeUpdate();
	   } 
	   catch (SQLException e)
	   {
		errorLog.saveToFile(str);
		//e.printStackTrace();
	}
   }
}
