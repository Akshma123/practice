package com.nucleus.dao;

import nucleus.domain.Book;

public interface BookDAO 
{
public void saveBook(Book book);
public Book getBookByBookId(int bookId);
}
