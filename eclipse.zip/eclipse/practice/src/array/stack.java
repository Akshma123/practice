package array;
import java.util.*;
public class stack 
{
	Scanner sc=new Scanner(System.in);
	static int size=-1;
	static int Stack[];
	void push()
	{
		if(size==1)
		{
			System.out.println("stack is full");
		}
		else
		{
			System.out.println("enter number");
			int num=sc.nextInt();
		size++;
		Stack[size]=num;
		System.out.println(size+":"+Stack[size]);
		}
	}
	void pop()
	{
		
	}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	stack s=new stack();
	 Stack=new int[2];
	 int var=1;
	 while(var==1)
	 {
	System.out.println("enter 1 to push");
	System.out.println("enter 2 to pop");
	System.out.println("3 to exit");
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		s.push();
		break;
	case 2:
		s.pop();
		break;
	case 3:
		var=0;
		
	}
	 }
}
}
