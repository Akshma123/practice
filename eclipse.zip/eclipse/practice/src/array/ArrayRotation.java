package array;
import java.util.*;
public class ArrayRotation 
{
      void rotate(int no,int[] arr,int n)
      {
    	  Scanner sc=new Scanner(System.in);
    	  for(int i=0;i<no;i++)
    	  {
    	  int last=arr[n-1];
    	  for(int j=n-1;j>=1;j--){
    	  arr[j]=arr[j-1];
    	  }
    	  arr[0]=last;
    	  }
    	  System.out.println("rotated array is");
    	  for(int k=0;k<n;k++)
    		  System.out.print(arr[k]+"  ");
    	  System.out.println("/nenter index");
    	  int index=sc.nextInt();
    	  System.out.println("value is "+arr[index]);
      }
}
class TestArrayRotation
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		ArrayRotation ar=new ArrayRotation();
		System.out.println("enter size of array");
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("how many times do u want to rotate");
		int no=sc.nextInt();
		 ar.rotate(no,arr,n);
		
	}
}
