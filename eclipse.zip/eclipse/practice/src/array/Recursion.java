package array;

import java.util.Scanner;

public class Recursion {
	public static void main(String[] args) {
		int a[]=new int[10];
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no. to be inserted");
		int l=sc.nextInt();
		System.out.println("enter the no. of time to rotate");
		int r=sc.nextInt();
		System.out.println("enter the array");
		for(int i=0;i<l;i++)
		{
			a[i]=sc.nextInt();
		}
		recur(r,a,l);
	}	
		static public void recur(int k,int s[],int l)
		{
			if(k==0)
			{
				for(int j=0;j<l;j++)
				{
					System.out.println(s[j]+" ");
				}
				
			}
			
			for(int g=0;g<l-1;g++)
			{
				
				s[g+1]=s[g];
			}
			s[0]=s[l-1];
			recur(k-1,s,l);
			
		
		
	}
}

