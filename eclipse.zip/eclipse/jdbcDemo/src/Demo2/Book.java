package Demo2;
import java.util.*;
public class Book
{
 Scanner sc=new Scanner(System.in);
  int id;
  String name;
  float price;
  
  public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
void entry()
{
	 System.out.println("enter id");
	 int id=sc.nextInt();
     setId(id);
     System.out.println("enter name");
     String name=sc.next();
     setName(name);
     System.out.println("enter price");
     float price=sc.nextFloat();
     setPrice(price);
}
}
