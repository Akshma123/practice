package Demo2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Operations
{
	 MakeConnection makeconnection=new MakeConnection();
	 Connection conn=makeconnection.makeConnection();
	 Book b=new Book();
	 Scanner sc=new Scanner(System.in);
	PreparedStatement pstmt;
	ResultSet resultset;
 void create()
 {
	 try {
		pstmt=conn.prepareStatement("create table student122(id number(5))");
		pstmt.executeUpdate();
		System.out.println("created");
	} catch (SQLException e) {
	    e.printStackTrace();
	}
 }
 void read()
 {
   try 
   {
	pstmt=conn.prepareStatement("select * from Book122");
    resultset=pstmt.executeQuery();
	while(resultset.next())
	{
		int bookId=resultset.getInt(1);
		String bookName=resultset.getString(2);
		float price=resultset.getFloat(3);
		System.out.println(bookId+" "+bookName+" "+price);
	}
   } 
   catch (SQLException e)
   {
	e.printStackTrace();
  }   	 
 }
 void insert()
 {
	 try {
		pstmt=conn.prepareStatement("insert into Book122 values(?,?,?)");
		b.entry();
		pstmt.setInt(1,b.getId());
		pstmt.setString(2,b.getName());
		pstmt.setFloat(3,b.getPrice());
		pstmt.executeUpdate();
	} catch (SQLException e)
	{
		e.printStackTrace();
	}
	 
 }
 void delete()
 {
	 try 
	 {
		pstmt=conn.prepareStatement("Delete from Book122");
		//pstmt.setInt(1,4);
		pstmt.executeUpdate();
		 System.out.println("deleted");
	} 
	 catch (SQLException e)
	 {
		e.printStackTrace();
	 }
 }
 void update()
 {
	 try {
		pstmt=conn.prepareStatement("update Book122 set bookName='java1' where bookId=101");
		 pstmt.executeUpdate();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
 }
 
}
