package Demo3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Demo2.MakeConnection;

public class Register
{
	MakeConnection makeconnection=new MakeConnection();
	Connection conn=makeconnection.makeConnection();
	PreparedStatement pstmt;
	ResultSet resultset;
  void signUp()
  {
	  try {
		pstmt=conn.prepareStatement("insert into validate122 values(?,?,?)");
		pstmt.setString(1,"akshma");
		pstmt.setString(2,"akki");
		pstmt.setInt(3,100);
		pstmt.executeUpdate();
		System.out.println("sign up successful");
  } catch (SQLException e) {
		e.printStackTrace();
	} 
  }
  void signIn(String userName,String password)
  {
	  try {
		pstmt=conn.prepareStatement("select * from validate122");
		resultset=pstmt.executeQuery();
		while(resultset.next())
		{
			String uName=resultset.getString(1);
			String p=resultset.getString(2);
			if(uName.equals(userName)&&p.equals(password))
					{
				System.out.println("welcome");
				break;
					}
		}	
		System.out.println("u r not registered!please sign up first");
	}
	  catch (SQLException e) {
		e.printStackTrace();
	} 
  }
}
