
package secondpackage;

import myFirstProject.*;

class Inherit1 extends Class1	
{
	protected void display()
	{
		super.display();
	}
}

public class class21
{	
	
	public static void main(String[] args)
	{	
			
		Inherit1 h=new Inherit1();
		h.display();
	}
	
}
