package myFirstProject;



 class Class2 {

	public static void main(String[] args) {
	
//Class cc=new Class();
//cc.display();
	}

}
public class Class1
{
	int id=0;
	String name="akk";
	protected void display()
	{
		System.out.println(id+" "+name);
	}
}

