//demo of getter and setter methods
public class GetterSetterDemo
{
//	data members should be private 
private int id;
private String name;

   public void setId(int id)
   {
	   this.id=id;
   }
   public void setName(String name)
   {
	   this.name=name;
   }
   public int getId()
   {
	   return id;
   }
   public String getName()
   {
	   return name;
   }
}  
class TestGetterSetterDemo
{
	public static void main(String[] args)
	{
		GetterSetterDemo d=new GetterSetterDemo();
		d.setId(a);
		System.out.println(d.getId());
	}
}

	

