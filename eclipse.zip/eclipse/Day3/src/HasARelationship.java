//has a relationship
public class HasARelationship {
     String name;
     Exam e;          //class exam reference variable
     public void display()
     {
    	 e=new Exam();
    	 System.out.println(name+" "+e.date+" "+e.month);
     }
	
public static void main(String[] args)
{
HasARelationship h=new HasARelationship();
h.display();
}
}
class Exam
{
	int date;
	int month;
}
