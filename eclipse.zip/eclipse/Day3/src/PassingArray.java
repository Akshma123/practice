import java.util.*;
public class PassingArray {

	  double findAvg(int[] arr,int n)
	  {
		  int sum=0;
		  for(int i=0;i<n;i++)
		  {
	
		  sum+=arr[i];
	  }
	      return(sum/n);
}
}
class TestPassingArray
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		int[] arr=new int[n];
		PassingArray pa=new PassingArray();
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		double res=pa.findAvg(arr, n);
		System.out.println(res);
		
	}
}

