package demo1;

public class PriorityDemo1 
{
 public static void main(String[] args) 
 {
      	
 }
}
class ChildThread3 extends Thread
{
	
}