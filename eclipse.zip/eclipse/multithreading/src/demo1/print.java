package demo1;

public class print 
{
 public static void main(String[] args)
 {
	 //Thread name =Thread.currentThread();
	// name.setName("master");
	 //System.out.println("name is "+name);
	 
	 //extending
	 ChildThread childThread=new ChildThread();
	childThread.start();
	try {
		childThread.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//implementing
	 
	for(int i=0;i<210;i++)
	{
		System.out.println("main thread "+i);
	}
 }
}
//thread created by extending the thread class
class ChildThread extends Thread
{
	public void run()
	{
		
		/*ChildThread1 childThread1=new ChildThread1();
		 Thread thread=new Thread(childThread1);
		 thread.start();*/
	for(int i=0;i<20;i++)
	{
		
		System.out.println("child thread "+i);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
}
//thread created by implementing the runnable interface
/*class ChildThread1 implements Runnable
{
	public void run()
	{
		System.out.println("thread name "+Thread.currentThread());
	for(int i=0;i<5;i++)
	{
		System.out.println("child thread1 "+i);
	}
	}
}*/