package demo1;

public class PriorityDemo
{
 public static void main(String[] args)
 {
	 Thread thread=Thread.currentThread();
	 thread.setPriority(3);
	 ChildThread1 childThread1=new ChildThread1();
	 childThread1.start();
 }
}
class ChildThread1 extends Thread
{
	public void run()
	{
	Thread thread1=Thread.currentThread();
	 System.out.println(thread1.getPriority());
	}
}