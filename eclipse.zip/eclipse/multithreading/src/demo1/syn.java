package demo1;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

class Get
{
	
	public synchronized void getFromFile(String path)
	{
		FileReader fileReader = null;
		BufferedReader bufferReader = null;
		try {
			fileReader = new FileReader(path);
			bufferReader = new BufferedReader(fileReader);
			try {
				String l = bufferReader.readLine();
				while(l != null)
				{
					System.out.println(l);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					l = bufferReader.readLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				fileReader.close();
				bufferReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
class ChildThread10 implements Runnable 
{
	Get get;
    String path;

	public ChildThread10(String path) {
		this.path = path;
	}

	public void setGet(Get get) {
		this.get = get;
	}

	public void run() {
		
		get.getFromFile(path);
		
	}
	
}
public class syn{
	
	public static void main(String[] args) {
		ChildThread10 childThread1 = new ChildThread10("abc.txt");
		ChildThread10 childThread2 = new ChildThread10("xyz.txt");
		Get get = new Get();
		Thread thread1 = new Thread(childThread1);
		childThread1.setGet(get);
		thread1.start();
		Thread thread2 = new Thread(childThread2);
		childThread2.setGet(get);
		thread2.start();
		
		
	}

}
