package synchronization;

public class Account 
{
 public static void main(String[] args)
 {
	ChildThread childThread1=new ChildThread();
	ChildThread childThread2=new ChildThread();
	Thread thread=new Thread(childThread1);
	Thread thread1=new Thread(childThread2);
	thread.start();
	thread1.start();
 }
}

class ChildThread implements Runnable
{
	int balance;
	public synchronized void deposit()
	{
		System.out.println("deposit method start");
		balance+=2000;
		System.out.println("notify");
		notify();
		System.out.println("deposit completed");
	}
	public synchronized void withdraw()
	{
		System.out.println("withdraw method start");
		if(balance<=0)
		{
			System.out.println("thread is going to wait");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		balance-=1000;
		System.out.println("withdraw completed");
	}
   public void run() 
   {

   }
	
}

	
