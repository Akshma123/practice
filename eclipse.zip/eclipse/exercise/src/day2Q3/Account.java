package day2Q3;

import java.util.Random;

class Account
{
	Random r = new Random();
	String name;
	String type;
	String accno = 1000 + r.nextInt(89999) + "";
	static double accbal;
	public Account(String name, double accbal, String type) {
		super();
		this.name = name;
		this.accbal = accbal;
		this.type = type;
		
	}
	


	public void setAccbal(double accbal) {
		this.accbal = accbal;
	}


	void deposit(double d)
	{
		System.out.println("Your Account Bal before Deposit is :" + accbal);
		accbal += d;
		setAccbal(accbal);
		System.out.println("Your Account Bal after Deposit " + d + " is :" + accbal);
	}
}