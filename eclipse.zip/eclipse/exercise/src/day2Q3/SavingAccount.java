package day2Q3;

public class SavingAccount extends Account
{
   int interest = 5;
   double maxWithdrawLimit;
   int time =1;
   double minBal = 500;
   
public SavingAccount(String name, double accbal, String type,  double maxWithdrawLimit) {
	super(name, accbal, type);
	this.maxWithdrawLimit = maxWithdrawLimit;
}
   double getBalance()
   {
	   double SI = (accbal * interest * time)/100;
	   double I = this.accbal + SI;
	   return I;
   }
   
   void withdraw(double d)
   {
	   if((d <= maxWithdrawLimit) && ((accbal-d) >= minBal))
	   {
		   accbal -= d;
		   setAccbal(accbal);
		   System.out.println("Hello " + name +" Rs " + d + " withdraw from your Account No " + accno);
		   System.out.println("Your Current Balance is" + accbal);
		   
	   }
	   else if(d > maxWithdrawLimit )
	   {
		   System.out.println("Sorry You have Reached Your Max Withdraw Limit");
	   }
	   else if ((accbal-d) <= minBal)
	   {
		   System.out.println("Sorry You dont have Sufficient Ammount");
	   }
   }
}

