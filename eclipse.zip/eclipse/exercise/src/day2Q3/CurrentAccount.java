package day2Q3;

public class CurrentAccount extends Account 
{
    String tradeLicenseNo;
    
    public CurrentAccount(String name, double accbal, String type,  String tradeLiceseNo) {
		super(name, accbal, type);
		this.tradeLicenseNo = tradeLicenseNo;
	}

	double getBalance()
    {
		setAccbal(accbal);
    	return this.accbal;
    }
	
	void withdraw(double d)
	{
		if(d <= accbal)
		{
			accbal -= d;
			setAccbal(accbal);
			System.out.println("Hello " + name +" Rs " + d + " withdraw from your Account No " + accno);
			   System.out.println("Your Current Balance is" + accbal);
		}
		else
		{
			System.out.println("You dont have Sufficent Amount");
		}
	}
    
}
