package day2Q3;

import java.util.Scanner;

public class Bank {
	static String n= null;
	static String t = null;
	static String tl = null;
	static double ib =0;
	static double mw =0;
	static void createAccount()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		      n = sc.next();
		System.out.println("Enter Type of Account, Saving Or Current");
		      t = sc.next();
		      if(t.equals("saving") || t.equals("Saving"))
		      {
		    	  System.out.println("Enter Max Withdraw Limit");
				     mw = sc.nextDouble();
		      }
		      else if(t.equals("current") || t.equals("Current"))
		      {
		    	  System.out.println("Enter Trading License No");
				     tl = sc.next();
		      }
		System.out.println("Enter Initial Bal");
		     ib = sc.nextDouble();
		
	}
	public static void main(String[] args) {
		         Scanner sc = new Scanner(System.in);
		         createAccount();
		         Account ac = new Account(n,ib,t);
		         SavingAccount sa = new SavingAccount(n,ib,t,mw);
		         CurrentAccount ca = new CurrentAccount(n,ib,t,tl);
		         while(true)
		         {
		         System.out.println("1 - Deposit");
		         System.out.println("2 - Withdraw");
		         System.out.println("3 - View Balance");
		         System.out.println("4 - exit");
		         System.out.println("Enter Your Choice");
		         int ch = sc.nextInt();
		         
		         switch(ch) 
		         {
		        	 case 1:
		        	 {
		        		 System.out.println("Enter the amount to be Deposit");
		        		 ac.deposit(sc.nextDouble());
		        		 break;
		        	 }
		        	 
		        	 case 2:
		        	 {
		        		 System.out.println("Enter the amount to be Withdraw");
		        		 double d = sc.nextDouble();
		        		 if(t.equals("saving") || t.equals("Saving"))
		        		 {
		        			 sa.withdraw(d);
		        		 }
		        		 else
		        		 {
		        			 ca.withdraw(d);
		        		 }
		        		 break;
		        	 }
		        	 
		        	 case 3:
		        	 {
		        		System.out.println("Your Account Bal is" + ca.getBalance()); 
		        		break;
		        	 }
		        	 
		        	 case 0:
		        	 {
		        		 break;
		        	 }
		         }
		         }  
		
		
	}

}

