package day1;

public class Fibbo
{
	void fibbo(int a,int b,int n,float sum)
	{
		if(n==21)
		{
		 float avg=sum/20;	
		 System.out.print("\navg is = ");
		 System.out.println(avg);
		}
		else
		{
		int c=a+b;
		sum+=c;
		System.out.print(c+" ");
		fibbo(b,c,n+1,sum);
		}
	}
	
}
class TestFibbo
{
	public static void main(String[] args)
	{
		int a,b;
		a=b=1;
		int n=3;
		Fibbo f=new Fibbo();
		System.out.print(a+" "+b+" ");
		float sum=2.0f;
		f.fibbo(a,b,n,sum);
	}
}
