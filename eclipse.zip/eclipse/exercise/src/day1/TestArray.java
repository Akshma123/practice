package day1;

public class TestArray {
	public static int[] copyOf(int[] array)
	{
		int arr1[]=array;
		return arr1;
	}
	public static void main(String[] args)
	{
	
	int arr[]={1,2,3,4};
		int arr1[]=copyOf(arr);
		for(int i:arr1)
		{
			System.out.print(i+" ");
		}
	}

}

