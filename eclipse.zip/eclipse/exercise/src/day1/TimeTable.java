package day1;

public class TimeTable {

	      void table()
	      {
	    	  for(int i=0;i<=9;i++)
	    	  {
	    		  if(i==0)
	    		  System.out.print("*|");
	    		  else
	    			  System.out.print(i+" ");
	    	  }
	    	  System.out.println();
	    	  for(int i=0;i<(2*9+1);i++)
	    		  System.out.print("-");
	    	  System.out.println();
	    	  int a;
	    	  for(int i=1;i<=9;i++)
	    	  {
	    		  System.out.print(i+"|");
	    		  for(int j=1;j<=9;j++)
	    		  {
	    			  a=i*j;
	    			  System.out.print(a+" ");
	    			}
	    		  System.out.println();
	    		  }
	    		 
	    	  }
	      }

class TestTimeTable
{
	public static void main(String[] args)
	{
		TimeTable t=new TimeTable();
		t.table();
	}
}