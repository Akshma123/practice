package day1;

import java.util.Scanner;

public class GradesAverage {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no. of students");
		int numStudents=sc.nextInt();
		int[] arr=new int[numStudents];
		float sum=0.0f;
		for(int i=0;i<numStudents;i++)
		{
			System.out.print("enter the grade of student"+(i+1)+":");
			int a=sc.nextInt();
			if(a<0||a>100)
			{
				System.out.println("invalid grade..try again");
				i--;
			}
			else
			{
				arr[i]=a;
				sum+=arr[i];
			}
		}
		float avg=sum/numStudents;
		System.out.println("The Average is:"+avg);
	}

}
