package day2;

public class Book {

}
