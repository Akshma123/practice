package day2;

class Account
{
 Random r = new Random();
	String name;
	String type;
	String accno = 1000 + r.nextInt(89999) + "";
	static double accbal;
	public Account(String name, double accbal, String type) {
		super();
		this.name = name;
		this.accbal = accbal;
		this.type = type;
		
	}
	


	public void setAccbal(double accbal) {
		this.accbal = accbal;
	}


	void deposit(double d)
	{
		System.out.println("Your Account Bal before Deposit is :" + accbal);
		accbal += d;
		setAccbal(accbal);
		System.out.println("Your Account Bal after Deposit " + d + " is :" + accbal);
	}
}
}
class SavingAccount
{
    int interest = 5;
   double maxWithdrawLimit;
   int time =1;
   double minBal = 500;
 public SavingAccount(String name, double accbal, String type,  double maxWithdrawLimit) {
	super(name, accbal, type);
	this.maxWithdrawLimit = maxWithdrawLimit;
}
   double getBalance()
   {
	   double SI = (accbal * interest * time)/100;
	   double I = this.accbal + SI;
	   return I;
   }
   
   void withdraw(double d)
   {
	   if((d <= maxWithdrawLimit) && ((accbal-d) >= minBal))
	   {
		   accbal -= d;
		   setAccbal(accbal);
		   System.out.println("Hello " + name +" Rs " + d + " withdraw from your Account No " + accno);
		   System.out.println("Your Current Balance is" + accbal);
		   
	   }
	   else if(d > maxWithdrawLimit )
	   {
		   System.out.println("Sorry You have Reached Your Max Withdraw Limit");
	   }
	   else if ((accbal-d) <= minBal)
	   {
		   System.out.println("Sorry You dont have Sufficient Ammount");
	   }
   }
 
}
class CurrentAccount
{
  
    String tradeLicenseNo;
    
    public CurrentAccount(String name, double accbal, String type,  String tradeLiceseNo) {
		super(name, accbal, type);
		this.tradeLicenseNo = tradeLicenseNo;
	}

	double getBalance()
    {
		setAccbal(accbal);
    	return this.accbal;
    }
	
	void withdraw(double d)
	{
		if(d <= accbal)
		{
			accbal -= d;
			setAccbal(accbal);
			System.out.println("Hello " + name +" Rs " + d + " withdraw from your Account No " + accno);
			   System.out.println("Your Current Balance is" + accbal);
		}
		else
		{
			System.out.println("You dont have Sufficent Amount");
		}
	}
    
}
class BnakingSystem
{
  createAccount()
{
  static void createAccount()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		      n = sc.next();
		System.out.println("Enter Type of Account, Saving Or Current");
		      t = sc.next();
		      if(t.equals("saving") || t.equals("Saving"))
		      {
		    	  System.out.println("Enter Max Withdraw Limit");
				     mw = sc.nextDouble();
		      }
		      else if(t.equals("current") || t.equals("Current"))
		      {
		    	  System.out.println("Enter Trading License No");
				     tl = sc.next();
		      }
		System.out.println("Enter Initial Bal");
		     ib = sc.nextDouble();
		
	}
}
public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
 createAccount();
Account ac = new Account(n,ib,t);
		         SavingAccount sa = new SavingAccount(n,ib,t,mw);
		         CurrentAccount ca = new CurrentAccount(n,ib,t,tl);
		         while(true)
		         {
		         System.out.println("1 - Deposit");
		         System.out.println("2 - Withdraw");
		         System.out.println("3 - View Balance");
		         System.out.println("4 - exit");
		         System.out.println("Enter Your Choice");
		         int ch = sc.nextInt();
		         
		         switch(ch) 
		         {
		        	 case 1:
		        	 {
		        		 System.out.println("Enter the amount to be Deposit");
		        		 ac.deposit(sc.nextDouble());
		        		 break;
		        	 }
		        	 
		        	 case 2:
		        	 {
		        		 System.out.println("Enter the amount to be Withdraw");
		        		 double d = sc.nextDouble();
		        		 if(t.equals("saving") || t.equals("Saving"))
		        		 {
		        			 sa.withdraw(d);
		        		 }
		        		 else
		        		 {
		        			 ca.withdraw(d);
		        		 }
		        		 break;
		        	 }
		        	 
		        	 case 3:
		        	 {
		        		System.out.println("Your Account Bal is" + ca.getBalance()); 
		        		break;
		        	 }
		        	 
		        	 case 0:
		        	 {
		        		 break;
		        	 }
		         }
		         }  
		
		
	}

}

}