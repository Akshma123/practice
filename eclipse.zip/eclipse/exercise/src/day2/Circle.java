package day2;

public class Circle 
{
	private double radius;
	private String color;
	public Circle()
	{
		radius=1.0;
		color="red";
	}
	public Circle(double r)
	{
	 this.radius=r;
	}
	public double getRadius()
	{
		return radius;
	}
	public double getArea()
	{
		return (3.14*radius*radius);
	}

}
class TestCircle
{
	public static void main(String[] args)
	{
	Circle c=new Circle();
	double radius=c.getRadius();
	double area=c.getArea();
	System.out.println(radius+" "+area);
	}
	
}
