package day2;
import java.util.*;
class Vehicle
{
 int noOfWheel=4;
 int noOfPassenger=4;
 int model=358;
 String make="06/2014";
 void display()
 {
  System.out.println(make+" - "+model+" - "+noOfWheel+" - "+noOfPassenger);
 }
}
class Car1 extends Vehicle
{
 int noOfDoor=3;
 void display()
 {
  System.out.print(make+"-"+model+"-"+noOfDoor);
 }
}
class Convertible extends Car1
{
 boolean isHoodOpen=true;
  void display()
 {
  super.display();
  System.out.println(" - "+isHoodOpen);
 }
}
class SportCar extends Car1
{
 int noOfDoor=2;
 void dispaly()
 {
   System.out.println(noOfDoor);
 }
}
class Application
{
public static void main(String[] args)
{
   Scanner sc=new Scanner(System.in);
   Vehicle v;
   System.out.println("enter 1 to create a vehicle object");
   System.out.println("enter 2 to create a car object");
   System.out.println("enter 3 to create a Convertible object");
   System.out.println("enter 4 to create a SportCar object");
   int choice=sc.nextInt();
   switch(choice)
   {
    case 1:
         v=new Vehicle();
         v.display();
         break;
    case 2:
         v=new Car1();
         v.display();
         break;
    case 3:
         v=new Convertible();
         v.display();
         break;
    case 4:
         v=new SportCar(); 
         v.display();
   }
} 
}
