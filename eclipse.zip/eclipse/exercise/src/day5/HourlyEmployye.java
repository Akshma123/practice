package day5;

public class HourlyEmployye extends Employee
{

}
