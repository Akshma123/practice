package day5;

public class Commission_employee extends Employee
{

}
