package day5;

public class Employee 
{

}
 class Salaried_employee extends Employee
{

}
 class HourlyEmployye extends Employee
{

}