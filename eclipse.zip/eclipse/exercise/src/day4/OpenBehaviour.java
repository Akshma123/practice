package day4;
public class OpenBehaviour {

    public static void main(String[] args)
    {
        Behaviour b = new Behaviour();
        b.open("opening a door", "opening a window", "opening a bank account", "opening a window", "opening a box");

    }

}

class Behaviour {

    public void open(String... a)
    {
        for(String a1:a)
            System.out.println(a1);
    }

    }
