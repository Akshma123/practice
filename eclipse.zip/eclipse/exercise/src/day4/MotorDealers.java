package day4;
import java.util.*;
class MotorDealers
{
 void modelOfCategory(String category)
 {
  if(category.equals("SUV"))
  System.out.println("TATA SAFARI");
  if(category.equals("SEDAN"))
  System.out.println("TATA INDIGO");
  if(category.equals("ECONOMY"))
  System.out.println("TATA INDICA");
  if(category.equals("MINI"))
  System.out.println("TATA NANO");
 }
}
class TestMotorDealers
{
 public static void main(String args[])
 {
  Scanner sc=new Scanner(System.in);
  MotorDealers m=new MotorDealers();
  System.out.println("enter category");
  String category=sc.next();
  m.modelOfCategory(category);
 }
}
