package day4;
class Worker
{
  String workerName;
  double salRate;
public Worker(String workerName, double salRate) {
	this.workerName = workerName;
	this.salRate = salRate;
}
  
}

class HourlyWorker extends Worker
{
	int hours;
	public HourlyWorker(String workerName, double salRate, int hours)
	{
		super(workerName, salRate);
		this.hours = hours;
	}

	void computePay()
	{
		double salary;
		if(hours <= 40)
		{
		    salary = (hours * super.salRate);
		}
		else
		{
			double compute = (hours - 40)*salRate*1.5;
			salary = (40*salRate + compute);
		}
		System.out.println("salary of Worker is: "+salary);
	}
}

class SalariedWorker extends Worker
{
	int hours;

	public SalariedWorker(String workerName, double salaryRate, int hours) {
		super(workerName, salaryRate);
		this.hours = hours;
	}
	
	void computePay()
	{
		double salary;
			salary = (40*salRate);
		System.out.println("salary of worker is: "+salary);
	}
}

 class TestWorker {

	public static void main(String[] args) {
			
		HourlyWorker hw = new HourlyWorker("Akshma", 30,41);
		SalariedWorker sw = new SalariedWorker("akki", 50,41);
		hw.computePay();
		sw.computePay();
		
	}

}

