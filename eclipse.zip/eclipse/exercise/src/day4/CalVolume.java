package day4;
import java.util.*;
class CalVolume
{
void volume(double s)
 {
  double volume=s*s*s;
  System.out.println("volume of cube:"+volume);
 }
 void volume(double r,double h)
{
  double volume=3.14*r*r*h;
  System.out.println("volume of cylinder:"+volume);
}
 void volume(double l,double b,double h)
{
 double volume=l*b*h;
  System.out.println("volume of rectangle:"+volume);
}
}
class TestCalVolume
{
 public static void main(String[] args)
 {
  Scanner sc=new Scanner(System.in);
   CalVolume c=new CalVolume();
  
   System.out.println("enter 1 to calculate volume of cube");
   System.out.println("enter 2 to calculate volume of cylinder");
    System.out.println("enter 3 to calculate volume of rectangle");
int choice=sc.nextInt();
 switch(choice)
{
 case 1:
     c.volume(3.4);
     break;
 case 2:
     c.volume(2.0,7.0);
       break;
 case 3:
     c.volume(2.3,3.3,4.0);
}
 }
}
