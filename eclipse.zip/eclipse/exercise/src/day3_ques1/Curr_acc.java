package day3_ques1;

public class Curr_acc extends Account
{
	double minBalance=500;
 public void checkBook()
 {
	 
 }
 public void minBalance(int i)
 {
	if(acc[i].balance<minBalance) 
	{
		int panelty=100;
		System.out.println("balance is: "+acc[i].balance);
		acc[i].balance-=panelty;
		System.out.println("now balance is: "+acc[i].balance);
	}
	else
		System.out.println("no panelty");
 }
}
