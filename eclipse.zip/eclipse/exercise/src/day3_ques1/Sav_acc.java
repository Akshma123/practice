package day3_ques1;
import java.lang.Math.*;
public class Sav_acc extends Account
{
 public void compoundInterest(int i)
 {
	int r=5;
	double n=1/2;
	double t=2;
	System.out.println("your balane is: "+acc[i].balance);
		double p=acc[i].balance;
		double inte=Math.pow(p*(1+r/n),(n*t));	
		// acc[i].balance=inte;
		//System.out.println("compound interest is: "+ci);
		//acc[i].balance+=ci;
		System.out.println("now balance is: "+inte);
		return;
		
	
 }
}
