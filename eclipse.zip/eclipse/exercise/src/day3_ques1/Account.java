package day3_ques1;

import java.util.Scanner;

public class Account
{
   String cName;
   String accNumber;
   String typeOfAccount;
   double balance;
   double initialAmount;
   static Account acc[];
	static int n;
	Scanner sc=new Scanner(System.in);
	public void enterDetails(int i)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the name of customer");
		String name=sc.next();
		System.out.println("enter the account no");
		String accountNo=sc.next();
		System.out.println("enter the type of account i.e saving or current");
		String type=sc.next();
		if(type.equals("current"))
		{
		System.out.println("enter initial account, the minimum 500 rs is madatory");
		double initialAmount=sc.nextDouble();
		if(initialAmount>=500)
		{
			
			acc[i].valueInitialize(name,type,accountNo,initialAmount);	
		}
		else
		{
			System.out.println("can't open your account");
		}
		}
		if(type.equals("saving"))
		{
			System.out.println("enter initial account, the minimum amount is 0 rs");
			double initialAmount=sc.nextDouble();
			acc[i].valueInitialize(name,type,accountNo,initialAmount);
		}
		
	}
   public void valueInitialize(String name,String type,String accNumber,double initialAmount)
   {
	 cName=name;
	 typeOfAccount=type;
	 this.accNumber=accNumber;
	 this.initialAmount=initialAmount;
	 balance+=initialAmount;
   }
   public void deposit(int i)
   {
	   System.out.println("enter the amount to added");
	   double amount=sc.nextDouble();
	   System.out.println("your available balance is: "+acc[i].balance);
	   acc[i].balance+=amount;
	   System.out.println("updated amount is: "+acc[i].balance);
   }
   public void withdraw(int i)
   {
	   System.out.println("enter the amount to withdraw");
	   double amount=sc.nextDouble();
	   System.out.println("your available balance is: "+acc[i].balance);
	   if(acc[i].balance>=amount)
	   {
	   acc[i].balance-=amount;
	   System.out.println("updated amount is: "+acc[i].balance); 
	   }
	   else
		   System.out.println("you have not sufficient balance to withdraw");
   }
   public static void main(String[] args)	
   {
  	 Scanner sc=new Scanner(System.in);
  	  acc=new Account[10];
  	  Curr_acc c=new Curr_acc();
  	  Sav_acc s=new Sav_acc();
  	  System.out.println("welcome! Enter the details of customers");
  	   System.out.println("enter the number of customers");
  	    n=sc.nextInt();
  		 for(int i=0;i<n;i++)
  	 {
  			acc[i]=new Account();
  		 acc[i].enterDetails(i);
  	 }
  		 int var=1;
  		 while(var==1)
  		 {
  		 System.out.println("enter 1 to deposit the money");
  		 System.out.println("enter 2 to display the balance");
  		 System.out.println("enter 3 to compute and deposit interest");
  		 System.out.println("enter 4 to withdraw the money");
  		 System.out.println("enter 5 to check for min balance");
  		 System.out.println("enter 6 to exit");
  		 int choice=sc.nextInt();
  		 switch(choice)
  		 {
  		 case 1:
  			System.out.println("enter the account no");
  		    String accNo=sc.next();
  		    for(int i=0;i<n;i++)
  			 {
  				 if(acc[i].accNumber.equals(accNo))
  				 {
  					acc[i].deposit(i);
  					
  				 }
  				 if(i==n)
  					 System.out.println("invalid acount number"); 
  			  }
  		   
  			break;
  		 case 2:
  			System.out.println("enter the account no");
  		    String accNo1=sc.next();
  		    for(int i=0;i<n;i++)
  		    {
  		    	if(acc[i].accNumber.equals(accNo1))
  		    	{
  		    		System.out.println("your balance is: "+acc[i].balance);
  		    	}
  		    }
  		  System.out.println("invalid acount number");
  		  break;
  		 case 3:
  			 System.out.println("enter account no");
  			 String accNo3=sc.next();
  			 for(int i=0;i<n;i++)
  			 {
  			 if(acc[i].accNumber.equals(accNo3))
  			 {
  			 if(acc[i].typeOfAccount.equals("saving"))
  			 {
  				 s.compoundInterest(i);
  			 }
  			 else
  				 System.out.println("no interest for current account");
  			 }
  			 }
  			 break;
  		 case 4:
  			System.out.println("enter the account no");
  		    String accNo4=sc.next();
  		    for(int i=0;i<n;i++)
  			 {
  				 if(acc[i].accNumber.equals(accNo4))
  				 {
  					acc[i].withdraw(i); 
  				 }
  			 }
  		  System.out.println("invalid acount number");
  		  break;
  		 case 5:
  				System.out.println("enter the account no");
  	  		    String accNo5=sc.next();
  	  		 for(int i=0;i<n;i++)
  			 {
  				 if(acc[i].accNumber.equals(accNo5))
  				 {
  					 if(acc[i].typeOfAccount.equals("current"))
  					 c.minBalance(i); 
  				 }
  				 else
  					 System.out.println("not for saving account");
  			 }
                break;
  			 
  			
  		 case 6:
  			 var=0;
  		 }
  			 
  		 }}
}
     

