package com.nucleus.validation;

import java.util.regex.Pattern;

import com.nucleus.domain.Customer;

public class Validate
{
	Customer c=new Customer();
   public boolean isCustomerNameValidate(String name,int l,int l1)
   {
	   if(name.equals(""))
	   {
		  return false;
	   }
	   if(1>l1)
		   return false;
	   char[] chars = name.toCharArray();
          for (char c : chars)
          {
	      if(!(Character.isLetterOrDigit(c)))
	      {
	    	  String ch=Character.toString(c);
	    	  if(!ch.equals(" "))
	            return false;
	      }
	    }

	  return true;
   }
   public boolean isEmailValid(String email,int l,int l1)
   {
	   if(email.equals("")||(l>l1))
		   return false;
	   String email1 = "^[a-zA-Z0-9_+&*-]+(?:\\."+
			           "[a-zA-Z0-9_+&*-]+)*@" +
                       "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                       "A-Z]{2,7}$";
       Pattern pat = Pattern.compile(email);
			 if (email == null)
			  return false;
	return pat.matcher(email).matches();
   }
   
   
   public boolean isCustomerPinCodeValid(long pinCode)
   {	  String str= Long.toString(pinCode);
	  if(str.equals(""))
		  return false;
	  if(str.length()==6)
		  return true;
	  return false;
   }
   public boolean isRecordStatusValid(String recordStatus,int l,int l1)
   {
	   String r=recordStatus.toUpperCase();
	   if(r.equals(""))
		   return false;
	   if(l>l1)
		   return false;
	   if(r.length()==1&&(r.equals("N")||r.equals("M")||r.equals("D")||r.equals("A")||r.equals("R")))
			   {
		     return true;
			   }
	   return false;
   }
   public boolean isActiveInactiveFlagValid(String flag,int l,int l1)
   {
	   String str=flag.toUpperCase();
	   if(str.equals(""))
		   return false;
	   if(l>l1)
		   return false;
	   if(str.length()==1&&(str.equals("A")||str.equals("I")))
	   {
		   return true;
	   }
	   return false;
   }
   public boolean isNull(String line,int l,int l1)
   {
	 if(line.equals("")||(l>l1)) 
		 return true;
	 return false;
   }
   public boolean isLengthValid(int l,int l1)
   {
	   if(l>l1)
		   return false;
	   return true;
   }
}
